# Practica_de_planificacion

## Índice
- Basico/ : Incluye el dominio, los problemas usados como juegos de prueba i el generador
- Extension_1/ : Incluye el dominio, los problemas usados como juegos de prueba i el generador
- Extension_2/ : Incluye el dominio, los problemas usados como juegos de prueba i el generador
- Extension_3/ : Incluye el dominio, los problemas usados como juegos de prueba i el generador
- Extension_4/ : Incluye el dominio, los problemas usados como juegos de prueba i el generador
- Extra_2 : Contiene los problemas usados en el extra 2
